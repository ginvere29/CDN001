1. Restore Database[CDN.bak] to local SSMS19.
2. Open the solution with visual studio 2022.
3. Update appsetting.json in CDN.API project:
	- ConnectionStrings
4. Start CDN.API by doing the following:
	- Open Command Prompt:
	- cd [Path to the CDN.API folder]
	- dotnet run
5. Start CDN.UI